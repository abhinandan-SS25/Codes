
public class CondMazeLab extends Maze 
{
    public static void main(String[] args) { 
       
        // Step 1: Run Maze Simulation
    }

    public void step() 
    {           
        // Steps 2 and 3: Implement HERE
        
    }       
    
    public CondMazeLab() { super(true); }
}